﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Project
{
    public class Role
    {
        //private string role { get; set; }

        //public Role(string userlog) 
        //{ 
        //    role = userlog; 
        //}
        public string Login { get; set; }
        public int roleType { get; set; }
        //public string Status => roleType ? "права Адміністратора" : "Користувач"; //true = 1 or false = 0
        public Role(string login, int roletype)
        {
            Login = login.Trim();
            roleType = roletype;
        }

        //    switch(roletype)
        //{
        //    case "Admin":
        //        MessageBox.Show("Вітаю, права Адміністратора надані!");
        //        break;
        //    case "Organizator":
        //        MessageBox.Show("Вітаю, права Організатора надані!");
        //        break;
        //    case "User":
        //        MessageBox.Show("Вітаю");
        //        break;
        //    default:
        //        MessageBox.Show("Неправильні дані", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        //        break;
        //}
    }
}

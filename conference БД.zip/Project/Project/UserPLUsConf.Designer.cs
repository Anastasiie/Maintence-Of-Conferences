﻿namespace Project
{
    partial class UserPLUsConf
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.Task1 = new System.Windows.Forms.DataGridView();
            this.dateConf = new System.Windows.Forms.TextBox();
            this.label_start = new System.Windows.Forms.Label();
            this.CountPers = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.New = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.Task1)).BeginInit();
            this.SuspendLayout();
            // 
            // Task1
            // 
            this.Task1.AllowUserToAddRows = false;
            this.Task1.AllowUserToDeleteRows = false;
            this.Task1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.Task1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Task1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(125)))), ((int)(((byte)(150)))), ((int)(((byte)(82)))));
            this.Task1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Task1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task1.DefaultCellStyle = dataGridViewCellStyle2;
            this.Task1.GridColor = System.Drawing.Color.White;
            this.Task1.Location = new System.Drawing.Point(21, 69);
            this.Task1.Name = "Task1";
            this.Task1.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Task1.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Transparent;
            this.Task1.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Task1.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.Task1.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.Task1.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Task1.ShowCellErrors = false;
            this.Task1.ShowCellToolTips = false;
            this.Task1.ShowEditingIcon = false;
            this.Task1.ShowRowErrors = false;
            this.Task1.Size = new System.Drawing.Size(883, 332);
            this.Task1.TabIndex = 0;
            this.Task1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.Task1_CellContentClick);
            // 
            // dateConf
            // 
            this.dateConf.BackColor = System.Drawing.SystemColors.ControlLight;
            this.dateConf.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.dateConf.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.dateConf.Location = new System.Drawing.Point(570, 24);
            this.dateConf.Margin = new System.Windows.Forms.Padding(2);
            this.dateConf.Multiline = true;
            this.dateConf.Name = "dateConf";
            this.dateConf.Size = new System.Drawing.Size(334, 40);
            this.dateConf.TabIndex = 80;
            this.dateConf.TextChanged += new System.EventHandler(this.dateConf_TextChanged);
            this.dateConf.Enter += new System.EventHandler(this.dateConf_Enter);
            // 
            // label_start
            // 
            this.label_start.AutoSize = true;
            this.label_start.BackColor = System.Drawing.Color.Transparent;
            this.label_start.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_start.ForeColor = System.Drawing.Color.Black;
            this.label_start.Location = new System.Drawing.Point(37, 31);
            this.label_start.Name = "label_start";
            this.label_start.Size = new System.Drawing.Size(246, 22);
            this.label_start.TabIndex = 79;
            this.label_start.Text = "Введіть дату конференції";
            // 
            // CountPers
            // 
            this.CountPers.BackColor = System.Drawing.SystemColors.ControlLight;
            this.CountPers.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.CountPers.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.CountPers.Location = new System.Drawing.Point(570, 421);
            this.CountPers.Margin = new System.Windows.Forms.Padding(2);
            this.CountPers.Multiline = true;
            this.CountPers.Name = "CountPers";
            this.CountPers.Size = new System.Drawing.Size(334, 40);
            this.CountPers.TabIndex = 82;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(50, 428);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 22);
            this.label1.TabIndex = 81;
            this.label1.Text = "Кількість учасників: ";
            // 
            // New
            // 
            this.New.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.New.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.New.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.New.Location = new System.Drawing.Point(517, 31);
            this.New.Name = "New";
            this.New.Size = new System.Drawing.Size(48, 26);
            this.New.TabIndex = 83;
            this.New.Text = "OK";
            this.New.UseVisualStyleBackColor = true;
            this.New.Click += new System.EventHandler(this.New_Click);
            // 
            // UserPLUsConf
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(97)))), ((int)(((byte)(116)))), ((int)(((byte)(63)))));
            this.ClientSize = new System.Drawing.Size(943, 501);
            this.Controls.Add(this.New);
            this.Controls.Add(this.CountPers);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateConf);
            this.Controls.Add(this.label_start);
            this.Controls.Add(this.Task1);
            this.Name = "UserPLUsConf";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UserPLUsConf";
            this.Load += new System.EventHandler(this.UserPLUsConf_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Task1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView Task1;
        private System.Windows.Forms.TextBox dateConf;
        private System.Windows.Forms.Label label_start;
        private System.Windows.Forms.TextBox CountPers;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button New;
    }
}
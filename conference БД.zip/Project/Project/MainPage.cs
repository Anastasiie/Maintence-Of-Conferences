﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Collections;

namespace Project
{
    enum RowState
    {
        Existed,
        New,
        Modified,
        ModifiedNew,
        Deleted
    }
    public partial class MainPage : Form
    {
        DB_Connection DB_Connection= new DB_Connection();
        int selectedRow;

        public MainPage()
        {
            InitializeComponent();

        }
        private void CreateColumns()
        {
            dataGridView1.Columns.Add("ConfRegNumb", "Реєстраційний номер конференції");
            dataGridView1.Columns.Add("ConfName", "Назва конференції");
            dataGridView1.Columns.Add("Country", "Країна");
            dataGridView1.Columns.Add("City", "Місто");
            dataGridView1.Columns.Add("StartDate", "Дата початку");
            dataGridView1.Columns.Add("EndDate", "Дата закінчення");
            dataGridView1.Columns.Add("IsNew", String.Empty);
        }
        private void ReadRow(DataGridView dataGridView, IDataRecord record) 
        {
            dataGridView.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetDateTime(4), record.GetDateTime(5), RowState.ModifiedNew);
        }

        private void RefreshDataGrid(DataGridView dataGridView) //Read
        {
            dataGridView.Rows.Clear();
            string querystring = $"select * from Conference";//ConfName, Country, City, StartDate, EndDate
            SqlCommand command = new SqlCommand(querystring, DB_Connection.getConnection());
            DB_Connection.openConnection();

            SqlDataReader reader = command.ExecuteReader();
            while(reader.Read())
            {   
                ReadRow(dataGridView,reader);
            }
            reader.Close();
            DB_Connection.closeConnection();
            
        }
        private void bindingNavigator1_RefreshItems(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorPositionItem_Click(object sender, EventArgs e)
        {

        }
        private void role()
        {
            var log = AllVariable.Login;
            var pass = AllVariable.Password;

            DB_Connection.openConnection();

            SqlCommand command = new SqlCommand("SELECT * FROM Member m INNER JOIN Role r ON m.userRole=r.roleId WHERE users_login = @login and users_password = @password", DB_Connection.getConnection());
            command.Parameters.AddWithValue("@login", log);
            command.Parameters.AddWithValue("@password", pass);

            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            sqlDataAdapter.Fill(dataTable);

            if (dataTable.Rows.Count > 0)
            {
                string usertype = dataTable.Rows[0][8].ToString();
                switch (usertype)
                {
                    case "Admin":
                        //MessageBox.Show("Вітаю, права Адміністратора надані!");
                        ADMIN.Visible = true;
                        textBox1.Text = "Admin";
                        break;
                    case "Organizator":
                        //MessageBox.Show("Вітаю, права Організатора надані!");
                        textBox1.Text = "Organizator";
                        break;
                    case "User":
                        New.Enabled = false;
                        button6.Enabled = false;
                        button7.Enabled = false;
                        button8.Enabled = false;
                        textBox1.Text = "User";
                        break;
                    default:
                        New.Enabled = false;
                        button6.Enabled = false;
                        button7.Enabled = false;
                        button8.Enabled = false;
                        textBox1.Text = "Guest";
                        //userRole = "UPDATE Member SET userRole = 3 WHERE Member.userRole = 0";
                        MessageBox.Show("Неправильні дані", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        break;
                }
            }
            DB_Connection.closeConnection();
        }
        private void MainPage_Load(object sender, EventArgs e)
        {
            role();
            //Size = new Size(1450, 953);// 1050, 534, 1020; 445
            FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Text = "Головна сторінка";
            CreateColumns();
            //RefreshDataGrid(dataGridView1);
            
            textBox_search.AddPlaceholder("Пошук");
            RefreshDataGrid(dataGridView1);
            this.dataGridView1.Columns["ConfRegNumb"].Visible = false;
            this.dataGridView1.Columns["IsNew"].Visible = false;
        }
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            
        }

        private void міжнародніНауковіКонференціїToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void bindingNavigatorPositionItem_Click_1(object sender, EventArgs e)
        {

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void вХІДРЕЄСТРАЦІЯToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void Nav1_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void Nav1_MouseEnter(object sender, EventArgs e)
        {
            
        }

        private void Nav1_MouseLeave(object sender, EventArgs e)
        {
            
        }

        private void label3_Click(object sender, EventArgs e)
        {
            
        }

        private void вхідToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.Hide();
            LogIn LogIn = new LogIn();
            LogIn.Show();
        }

        private void реєстраціяToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //this.Hide();
            Registration Reg = new Registration();
            Reg.Show();
        }

        private void MainPage_Leave(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void NavigationPanel_Enter(object sender, EventArgs e)
        {
            
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void вхідToolStripMenuItem_LocationChanged(object sender, EventArgs e)
        {

        }

        private void вХІДРЕЄСТРАЦІЯToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            //this.Hide();
            LogIn LogIn = new LogIn();
            LogIn.Show();
        }

        private void вХІДРЕЄСТРАЦІЯToolStripMenuItem_MouseHover(object sender, EventArgs e)
        {

        }

        private void міжнародніНауковіКонференціїToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            MainPage mainPage = new MainPage();
            mainPage.Show();
        }

        private void вХІДРЕЄСТРАЦІЯToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            //this.Hide();
            LogIn logIn = new LogIn();
            logIn.Show();
        }

        private void архівКонференційToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Archive archive = new Archive();
            archive.Show();
        }

        private void gradientmenustrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
           
        }

        private void Reg1_Click(object sender, EventArgs e)
        {
            
        }

        private void Reg1_MouseHover(object sender, EventArgs e)
        {
            
        }

        private void Reg2_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
        }

        private void Reg1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void Reg4_Click(object sender, EventArgs e)
        {
            
        }

        private void MenuItem3_Click(object sender, EventArgs e)
        {
            //this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void Person_Data_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Archive archive = new Archive();
            archive.Show();
        }

        private void Reg1_Click_2(object sender, EventArgs e)
        {
            Pay pay = new Pay();
            pay.Show();
            //Reg1.BackColor = Color.FromArgb(129, 213, 195);
            //Reg1.Text = "Успішно";
        }

        private void Reg2_Click_1(object sender, EventArgs e)
        {
            Pay pay = new Pay();
            pay.Show();
            //Reg2.BackColor = Color.FromArgb(129, 213, 195);
            //Reg2.Text = "Успішно";
        }

        private void Reg3_Click(object sender, EventArgs e)
        {
            Pay pay = new Pay();
            pay.Show();
            //Reg3.BackColor = Color.FromArgb(129, 213, 195);
            //Reg3.Text = "Успішно";
        }

        private void Reg4_Click_1(object sender, EventArgs e)
        {
            Pay pay = new Pay();
            pay.Show();
            //Reg4.BackColor = Color.FromArgb(129, 213, 195);
            //Reg4.Text = "Успішно";
        }

        private void Reg5_Click(object sender, EventArgs e)
        {
            Pay pay = new Pay();
            pay.Show();
            //Reg5.BackColor = Color.FromArgb(129, 213, 195);
            //Reg5.Text = "Успішно";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Contacts contacts = new Contacts();
            contacts.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Materials materials = new Materials();
            materials.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RefreshDataGrid(dataGridView1);
        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void toolStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
           
        }

        private void New_Click(object sender, EventArgs e)
        {
            AddConference addConference = new AddConference();
            addConference.Show();
            RefreshDataGrid(dataGridView1);
        }

        private void Search(DataGridView dataGridView) //Поиск
        {
            dataGridView.Rows.Clear();
            string searchString = $"select * from Conference where concat (ConfRegNumb, ConfName, Country, City, StartDate, EndDate) like '%" + textBox_search.Text + "%'";
            
            SqlCommand command = new SqlCommand(searchString,DB_Connection.getConnection());
            DB_Connection.openConnection();
            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadRow(dataGridView, reader);
            }
            reader.Close();
            DB_Connection.closeConnection();
        }
        private void DeleteRow()//Удаление
        {
            int index = dataGridView1.CurrentCell.RowIndex; //поточна строка
            dataGridView1.Rows[index].Visible = false;

            if (dataGridView1.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {
                dataGridView1.Rows[index].Cells[6].Value = RowState.Deleted;
                return;
            }
            dataGridView1.Rows[index].Cells[6].Value = RowState.Deleted;
        }

        private void uPdate()
        {
            DB_Connection.openConnection();

            for(int i = 0; i < dataGridView1.Rows.Count; i++)
            {
                var rowState = (RowState)dataGridView1.Rows[i].Cells[6].Value;
                if(rowState == RowState.Existed)
                {
                    continue;
                }
                if(rowState == RowState.Deleted)
                {
                    var Numb = Convert.ToInt32(dataGridView1.Rows[i].Cells[0].Value); //index текущ.строки, знач. 0 стовпця
                    var daleteQuery = $"delete from Conference where ConfRegNumb = {Numb}";

                    var command = new SqlCommand(daleteQuery, DB_Connection.getConnection());
                    command.ExecuteNonQuery();
                }
                if(rowState == RowState.Modified)
                {
                    var numbConf = dataGridView1.Rows[i].Cells[0].Value.ToString();
                    var nameConf = dataGridView1.Rows[i].Cells[1].Value.ToString();
                    var countryConf = dataGridView1.Rows[i].Cells[2].Value.ToString();
                    var cityConf = dataGridView1.Rows[i].Cells[3].Value.ToString();
                    var dateStart = dataGridView1.Rows[i].Cells[4].Value.ToString();
                    var dateEnD = dataGridView1.Rows[i].Cells[5].Value.ToString();

                    string changeQuery = $"update Conference set ConfName = '{nameConf}', Country  = '{countryConf}', City  = '{cityConf}', StartDate  = '{dateStart}', EndDate  = '{dateEnD}' where ConfRegNumb = '{numbConf}'";
                    SqlCommand command = new SqlCommand(changeQuery, DB_Connection.getConnection());
                    command.ExecuteNonQuery();
                }
            }
            DB_Connection.closeConnection();
        }
        private void search_Click(object sender, EventArgs e)
        {
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            DeleteRow();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            uPdate();
        }

        private void Change()
        {
            var selectedRowIndex = dataGridView1.CurrentCell.RowIndex;

            var numbConf = numb.Text;
            var nameConf = textBox2.Text;
            var countryConf = textBox3.Text;
            var cityConf = textBox4.Text;
            var dateStart = textBox5.Text; //strt
            var dateEnD = textBox5.Text;

            if (dataGridView1.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
            {
                
                dataGridView1.Rows[selectedRowIndex].SetValues(numbConf, nameConf, countryConf, cityConf, dateStart, dateEnD);
                dataGridView1.Rows[selectedRowIndex].Cells[6].Value = RowState.Modified;
            }
            
        }
        private void button7_Click(object sender, EventArgs e)
        {
            Change();
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[selectedRow];
                numb.Text = row.Cells[0].Value.ToString();
                textBox2.Text = row.Cells[1].Value.ToString();
                textBox3.Text = row.Cells[2].Value.ToString();
                textBox4.Text = row.Cells[3].Value.ToString();
                textBox5.Text = row.Cells[4].Value.ToString(); //strt
                textBox6.Text = row.Cells[5].Value.ToString();
            }
        }

        private void textBox_search_TextChanged(object sender, EventArgs e)
        {
            Search(dataGridView1);
        }

        private void numb_TextChanged(object sender, EventArgs e)
        {

        }

        private void label_Country_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            
        }

        private void label6_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button15_Click(object sender, EventArgs e)
        {
            tasks tasks = new tasks();
            tasks.Show();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Hide();
            Materials materials = new Materials();
            materials.Show();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            this.Hide();
            Contacts contacts = new Contacts();
            contacts.Show();
        }

        private void button13_Click(object sender, EventArgs e)
        {
            this.Hide();
            Archive archive = new Archive();
            archive.Show();
        }

        private void ADMIN_Click(object sender, EventArgs e)
        {
            AdInMin admin = new AdInMin();
            admin.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(this.Opacity > 0.0)
            {
                this.Opacity -= 0.025;
            }
            else
            {
                timer1.Stop();
                Application.Exit();
            }
        }

        private void MainPage_FormClosed(object sender, FormClosedEventArgs e)
        {
            
        }

        private void button9_Click_1(object sender, EventArgs e)
        {
            var loGin = AllVariable.Login;
            var pasSword = AllVariable.Password;

            int index = dataGridView1.CurrentCell.RowIndex; //текущ строка

            if (index >= 0)
            {
                var row = dataGridView1.Rows[selectedRow];
                var currConf = row.Cells[0].Value.ToString();
                DB_Connection.openConnection();
                var RegistrNumbPerson = $"SELECT RegistrNumbPerson FROM Member WHERE users_login = '{loGin}' AND users_password ='{pasSword}'";
                
                SqlCommand comm = new SqlCommand(RegistrNumbPerson, DB_Connection.getConnection());
                SqlDataReader dataReader = comm.ExecuteReader();

                int person = 0;
                while (dataReader.Read())
                {
                    person = Convert.ToInt32(dataReader[0]); //3
                }
                DB_Connection.closeConnection();
                DB_Connection.openConnection();
                var ConfRegNumb = $"SELECT ConfRegNumb FROM Conference WHERE ConfRegNumb = '{currConf}'";
                SqlCommand command = new SqlCommand(ConfRegNumb, DB_Connection.getConnection());
                SqlDataReader dr = command.ExecuteReader();

                int conf = 0;
                while (dr.Read())
                {
                    conf = Convert.ToInt32(dr[0]); //3
                }
                DB_Connection.closeConnection();
                DB_Connection.openConnection();
                
                var addQuery = $"INSERT into Registration values('{conf}','{person}', CURRENT_TIMESTAMP);";
                var coMmand = new SqlCommand(addQuery, DB_Connection.getConnection());
                coMmand.ExecuteNonQuery();
                
                AllVariable.ConferNumb = conf.ToString();
                AllVariable.PersonNumb = person.ToString();
                var addquery = $"INSERT into AdmissionFee values('{conf}', '{person}',0.00,'Не сплачено',CURRENT_TIMESTAMP)";
                var coand = new SqlCommand(addquery, DB_Connection.getConnection());
                coand.ExecuteNonQuery();
              
                DB_Connection.closeConnection();
                MessageBox.Show("Зареєстровано на конференцію", "Успішно!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Pay pay = new Pay();
                pay.Show();
            }
        }

        private void MainPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            timer1.Start();
        }

        private void MainPage_ControlRemoved(object sender, ControlEventArgs e)
        {

        }

        private void button14_Click(object sender, EventArgs e)
        {

        }
    }
}

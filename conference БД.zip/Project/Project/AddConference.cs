﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class AddConference : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public AddConference()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button8_Click(object sender, EventArgs e)
        {
            DB_Connection.openConnection();

            var nConf = textBox1.Text;
            var country = textBox2.Text;
            var city = textBox3.Text;
            var dataStart = textBox4.Text;//= textBox4.Text
            var dataEnd = textBox5.Text;

            //if(int.TryParse(textBox4.Text, out dataStart)){
            var addQuery = $"insert into Conference(ConfName, Country, City, StartDate, EndDate) values ('{nConf}', '{country}', '{city}', '{dataStart}', '{dataEnd}')";
            var command = new SqlCommand(addQuery, DB_Connection.getConnection());
            command.ExecuteNonQuery();
            //}
            MessageBox.Show("Запис успішно створено!","Успішно",MessageBoxButtons.OK,MessageBoxIcon.Information);
            //else
            //{
            //    MessageBox.Show("Невірний формат дати", "Помилка!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            //}
            DB_Connection.closeConnection();
            this.Close();
        }

        private void AddConference_Load(object sender, EventArgs e)
        {
            textBox4.AddPlaceholder("рр/мм/дд год:хв:сек.000");
            textBox5.AddPlaceholder("рр/мм/дд год:хв:сек.000");
        }
    }
}

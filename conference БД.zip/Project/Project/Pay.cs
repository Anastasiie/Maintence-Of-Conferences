﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Pay : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public Pay()
        {

            InitializeComponent();
        }

        private void PIB_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Pay_Load(object sender, EventArgs e)
        {
            Sum.AddPlaceholder("0.00");
            Coment.AddPlaceholder("Тут вкажіть необхідну інформацію");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        
        private void Reg2_Click(object sender, EventArgs e)
        {
           
        }
            
        

        private void button1_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void button1_MouseEnter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void gPay_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Платіж успішний");
        }

        private void tfPay_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Платіж успішний");
        }

        private void Reg2_Click_1(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Ви впевнені?", "Підтвердження операції", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                MessageBox.Show("Оплата виконана успішно", "Виконано", MessageBoxButtons.OK, MessageBoxIcon.Information);

                var ppl = AllVariable.PersonNumb;
                var ncon = AllVariable.ConferNumb;

                var sum = Sum.Text;
                var coment = Coment.Text;

                string addquery = $"Update AdmissionFee set PaymentAmount = '{sum}', Comment = '{coment}' WHERE RegistrNumbPerson = {ppl} and ConfRegNumb = {ncon} and PaymentAmount = 0";

                DB_Connection.openConnection();
                SqlCommand coand = new SqlCommand(addquery, DB_Connection.getConnection());
                coand.ExecuteNonQuery();

                DB_Connection.closeConnection();
                this.Hide();
            }
            else MessageBox.Show("Відмова операції", "Виконано", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

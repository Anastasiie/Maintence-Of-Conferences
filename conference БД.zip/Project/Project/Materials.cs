﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Materials : Form
    {
        DB_Connection DB_Connection = new DB_Connection();

        public Materials()
        {
            InitializeComponent();
        }

        private void Person_Data_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainPage mainPage = new MainPage();
            mainPage.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Archive archive = new Archive();
            archive.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Contacts contacts = new Contacts();
            contacts.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage  = new PersonalPage();
            personalPage.Show();
        }

        private void Person_Data_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            MainPage mainPage = new MainPage();
            mainPage.Show();
        }
        private void insert()
        {
            
            var conf = textBox4.Text;
            var adress = textBox1.Text;
            var mail_cod = textBox3.Text;
            var phonenumb = NomerTel.Text;
            var email = textBox2.Text;
            
            string addQuery = $"INSERT into Materials values('{conf}','"+textBox1.Text+"', '"+textBox3.Text+"', '"+NomerTel.Text+"', '"+textBox2.Text+"')";
            DB_Connection.openConnection();
            SqlCommand coMmand = new SqlCommand(addQuery, DB_Connection.getConnection());
            coMmand.ExecuteNonQuery();
            DB_Connection.closeConnection();
        }
        private void Materials_Load(object sender, EventArgs e)
        {
            
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Contacts contacts = new Contacts();
            contacts.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Archive archive = new Archive();
            archive.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void Materials_Leave(object sender, EventArgs e)
        {
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            insert();
            MessageBox.Show("Дякуємо за співпрацю. З вами зв'яжуться та нададуть потрібні дані", "Дані додані", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}

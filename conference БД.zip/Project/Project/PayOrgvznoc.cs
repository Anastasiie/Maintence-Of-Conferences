﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class PayOrgvznoc : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public PayOrgvznoc()
        {
            InitializeComponent();
        }
        private void ReadRow(IDataRecord record)
        {
            Task2.Rows.Add(record.GetString(0), record.GetDateTime(1), record.GetDecimal(2));
        }
        private void CreateColumns()
        {
            Task2.Columns.Add("FullName", "ПІБ"); //FullName, DateReg, StartDate
            Task2.Columns.Add("DatePay", "Дата сплати оргвнеску");
            Task2.Columns.Add("PaymentAmount", "Сплачені кошти");
        }
        
        private void PayOrgvznoc_Load(object sender, EventArgs e)
        {
            CreateColumns();
            datePay.AddPlaceholder("рр/мм/дд 00:00:00.000");
        }

        private void Task1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void New_Click(object sender, EventArgs e)
        {
            var date = datePay.Text;
            var stringQuery = $"SELECT FullName, DatePay, PaymentAmount FROM Member m JOIN AdmissionFee a ON m.RegistrNumbPerson=a.RegistrNumbPerson JOIN Conference c ON a.ConfRegNumb=c.ConfRegNumb WHERE c.StartDate = '{date}' and a.PaymentAmount>0 ORDER BY FullName";//'2022/12/04 9:15:01.000'
            SqlCommand command = new SqlCommand(stringQuery, DB_Connection.getConnection());
            DB_Connection.openConnection();

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadRow(reader);
            }
            reader.Close();
            DB_Connection.closeConnection();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project
{
    static class AllVariable
    {
        public static string Login;
        public static string Password;
        public static string ConferNumb;
        public static string PersonNumb;
    }
}

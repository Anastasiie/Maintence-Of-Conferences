﻿namespace Project
{
    partial class PayOrgvznoc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.datePay = new System.Windows.Forms.TextBox();
            this.label_start = new System.Windows.Forms.Label();
            this.New = new System.Windows.Forms.Button();
            this.Task2 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.Task2)).BeginInit();
            this.SuspendLayout();
            // 
            // datePay
            // 
            this.datePay.BackColor = System.Drawing.SystemColors.ControlLight;
            this.datePay.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.datePay.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.datePay.Location = new System.Drawing.Point(516, 36);
            this.datePay.Margin = new System.Windows.Forms.Padding(2);
            this.datePay.Multiline = true;
            this.datePay.Name = "datePay";
            this.datePay.Size = new System.Drawing.Size(328, 40);
            this.datePay.TabIndex = 83;
            // 
            // label_start
            // 
            this.label_start.AutoSize = true;
            this.label_start.BackColor = System.Drawing.Color.Transparent;
            this.label_start.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_start.ForeColor = System.Drawing.Color.Black;
            this.label_start.Location = new System.Drawing.Point(24, 44);
            this.label_start.Name = "label_start";
            this.label_start.Size = new System.Drawing.Size(302, 22);
            this.label_start.TabIndex = 82;
            this.label_start.Text = "Введіть дату оплати оргвзнесків";
            // 
            // New
            // 
            this.New.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.New.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.New.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.New.Location = new System.Drawing.Point(463, 44);
            this.New.Name = "New";
            this.New.Size = new System.Drawing.Size(48, 26);
            this.New.TabIndex = 85;
            this.New.Text = "OK";
            this.New.UseVisualStyleBackColor = true;
            this.New.Click += new System.EventHandler(this.New_Click);
            // 
            // Task2
            // 
            this.Task2.AllowUserToAddRows = false;
            this.Task2.AllowUserToDeleteRows = false;
            this.Task2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.Task2.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Task2.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(232)))), ((int)(((byte)(228)))), ((int)(((byte)(171)))));
            this.Task2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Task2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task2.DefaultCellStyle = dataGridViewCellStyle2;
            this.Task2.GridColor = System.Drawing.Color.White;
            this.Task2.Location = new System.Drawing.Point(8, 81);
            this.Task2.Name = "Task2";
            this.Task2.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task2.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Task2.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Transparent;
            this.Task2.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Task2.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.Task2.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.Task2.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Task2.ShowCellErrors = false;
            this.Task2.ShowCellToolTips = false;
            this.Task2.ShowEditingIcon = false;
            this.Task2.ShowRowErrors = false;
            this.Task2.Size = new System.Drawing.Size(883, 332);
            this.Task2.TabIndex = 86;
            // 
            // PayOrgvznoc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(188)))), ((int)(((byte)(184)))), ((int)(((byte)(121)))));
            this.ClientSize = new System.Drawing.Size(903, 450);
            this.Controls.Add(this.Task2);
            this.Controls.Add(this.New);
            this.Controls.Add(this.datePay);
            this.Controls.Add(this.label_start);
            this.Name = "PayOrgvznoc";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "PayOrgvznoc";
            this.Load += new System.EventHandler(this.PayOrgvznoc_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Task2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox datePay;
        private System.Windows.Forms.Label label_start;
        private System.Windows.Forms.Button New;
        private System.Windows.Forms.DataGridView Task2;
    }
}
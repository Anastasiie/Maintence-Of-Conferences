﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace Project
{
    public static class Placeholder
    {
        public static void AddPlaceholder(this TextBox tb, string placeholderText)
        { 
            tb.ForeColor = Color.Gray;
            tb.Text = placeholderText;
            tb.Enter += (s, e) => //лямда
            {
                if (tb.Text == placeholderText)
                {
                    tb.Text = "";
                    tb.ForeColor= Color.Black;
                }
            };
            tb.Leave += (s, e) =>
            {
                if(tb.Text == "")
                {
                    tb.ForeColor=Color.Gray;
                    tb.Text=placeholderText;
                }
            };
        }
        public static void AddComboBoxPlaceholder(this ComboBox cb, string placeholderText)
        {
            cb.ForeColor = Color.Gray;
            cb.Text = placeholderText;
            cb.Enter += (s, e) => //лямда
            {
                if (cb.Text == placeholderText)
                {
                    cb.Text = "";
                    cb.ForeColor = Color.Black;
                }
            };
            cb.Leave += (s, e) =>
            {
                if (cb.Text == "")
                {
                    cb.ForeColor = Color.Gray;
                    cb.Text = placeholderText;
                }
            };
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class YourConferRecord : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public YourConferRecord()
        {
            InitializeComponent();
        }
       
        private void CreateColumns()
        {
            //ConferRec.Columns.Add("ConfRegNumb", "Реєстраційний номер конференції");
            ConferRec.Columns.Add("ConfName", "Назва конференції");
            ConferRec.Columns.Add("Country", "Країна");
            ConferRec.Columns.Add("City", "Місто");
            ConferRec.Columns.Add("StartDate", "Дата початку");
           // ConferRec.Columns.Add("EndDate", "Дата закінчення");
        } 
        private void ReadRow(IDataRecord record)
        {
            ConferRec.Rows.Add(record.GetString(0), record.GetString(1), record.GetString(2), record.GetDateTime(3));
        }
        
        private void YourConferRecord_Load(object sender, EventArgs e)
        {
            CreateColumns();
            
            var loGin = AllVariable.Login;
            var pasSword = AllVariable.Password;

            var stringQuery = $"SELECT ConfName,City,Country,StartDate FROM Conference c JOIN Registration r ON r.ConfRegNumb=c.ConfRegNumb JOIN Member m ON m.RegistrNumbPerson=r.RegistrNumbPerson WHERE users_login = '{loGin}' AND users_password ='{pasSword}'";
            SqlCommand command = new SqlCommand(stringQuery, DB_Connection.getConnection());
            DB_Connection.openConnection();

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadRow(reader);
            }
            reader.Close();
            DB_Connection.closeConnection();
        }

        private void ConferRec_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainPage mainPage = new MainPage();
            mainPage.Show();
        }

        private void Person_Data_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonOrgVneski personOrgVneski = new PersonOrgVneski();
            personOrgVneski.Show();
        }
    }
}

﻿namespace Project
{
    partial class NOpayIntervalDate
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dateBefore = new System.Windows.Forms.TextBox();
            this.label_start = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.dateAfter = new System.Windows.Forms.TextBox();
            this.New = new System.Windows.Forms.Button();
            this.Task3 = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.Task3)).BeginInit();
            this.SuspendLayout();
            // 
            // dateBefore
            // 
            this.dateBefore.BackColor = System.Drawing.SystemColors.ControlLight;
            this.dateBefore.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.dateBefore.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.dateBefore.Location = new System.Drawing.Point(89, 60);
            this.dateBefore.Margin = new System.Windows.Forms.Padding(2);
            this.dateBefore.Multiline = true;
            this.dateBefore.Name = "dateBefore";
            this.dateBefore.Size = new System.Drawing.Size(328, 40);
            this.dateBefore.TabIndex = 85;
            // 
            // label_start
            // 
            this.label_start.AutoSize = true;
            this.label_start.BackColor = System.Drawing.Color.Transparent;
            this.label_start.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_start.ForeColor = System.Drawing.Color.Black;
            this.label_start.Location = new System.Drawing.Point(257, 21);
            this.label_start.Name = "label_start";
            this.label_start.Size = new System.Drawing.Size(294, 22);
            this.label_start.TabIndex = 84;
            this.label_start.Text = "Введіть інтервал дат оргвзносів";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(44, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(21, 22);
            this.label1.TabIndex = 86;
            this.label1.Text = "З";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(359, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 22);
            this.label2.TabIndex = 87;
            this.label2.Text = "До";
            // 
            // dateAfter
            // 
            this.dateAfter.BackColor = System.Drawing.SystemColors.ControlLight;
            this.dateAfter.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.dateAfter.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.dateAfter.Location = new System.Drawing.Point(414, 104);
            this.dateAfter.Margin = new System.Windows.Forms.Padding(2);
            this.dateAfter.Multiline = true;
            this.dateAfter.Name = "dateAfter";
            this.dateAfter.Size = new System.Drawing.Size(328, 40);
            this.dateAfter.TabIndex = 88;
            // 
            // New
            // 
            this.New.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.New.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.New.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.New.Location = new System.Drawing.Point(747, 149);
            this.New.Name = "New";
            this.New.Size = new System.Drawing.Size(113, 26);
            this.New.TabIndex = 90;
            this.New.Text = "OK";
            this.New.UseVisualStyleBackColor = true;
            this.New.Click += new System.EventHandler(this.New_Click);
            // 
            // Task3
            // 
            this.Task3.AllowUserToAddRows = false;
            this.Task3.AllowUserToDeleteRows = false;
            this.Task3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.Task3.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.Task3.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(127)))), ((int)(((byte)(197)))), ((int)(((byte)(247)))));
            this.Task3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.Task3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task3.DefaultCellStyle = dataGridViewCellStyle2;
            this.Task3.GridColor = System.Drawing.Color.White;
            this.Task3.Location = new System.Drawing.Point(6, 181);
            this.Task3.Name = "Task3";
            this.Task3.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Transparent;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.Task3.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.Task3.RowTemplate.DefaultCellStyle.BackColor = System.Drawing.Color.Transparent;
            this.Task3.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Task3.RowTemplate.DefaultCellStyle.ForeColor = System.Drawing.Color.Black;
            this.Task3.RowTemplate.DefaultCellStyle.SelectionBackColor = System.Drawing.Color.Transparent;
            this.Task3.RowTemplate.DefaultCellStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.Task3.ShowCellErrors = false;
            this.Task3.ShowCellToolTips = false;
            this.Task3.ShowEditingIcon = false;
            this.Task3.ShowRowErrors = false;
            this.Task3.Size = new System.Drawing.Size(924, 332);
            this.Task3.TabIndex = 91;
            // 
            // NOpayIntervalDate
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(178)))), ((int)(((byte)(227)))));
            this.ClientSize = new System.Drawing.Size(950, 522);
            this.Controls.Add(this.Task3);
            this.Controls.Add(this.New);
            this.Controls.Add(this.dateAfter);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dateBefore);
            this.Controls.Add(this.label_start);
            this.Name = "NOpayIntervalDate";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NOpayIntervalDate";
            this.Load += new System.EventHandler(this.NOpayIntervalDate_Load);
            ((System.ComponentModel.ISupportInitialize)(this.Task3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox dateBefore;
        private System.Windows.Forms.Label label_start;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox dateAfter;
        private System.Windows.Forms.Button New;
        private System.Windows.Forms.DataGridView Task3;
    }
}
﻿namespace Project
{
    partial class Pay
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.gradientpanel1 = new Project.gradientpanel();
            this.label5 = new System.Windows.Forms.Label();
            this.Reg2 = new System.Windows.Forms.Button();
            this.Coment = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AcadStatu = new System.Windows.Forms.ComboBox();
            this.Sum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.gradientpanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.Gray;
            this.label4.Location = new System.Drawing.Point(0, 417);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(595, 44);
            this.label4.TabIndex = 46;
            this.label4.Text = "------------------------------------------------";
            // 
            // gradientpanel1
            // 
            this.gradientpanel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(188)))), ((int)(((byte)(145)))));
            this.gradientpanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.gradientpanel1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(150)))), ((int)(((byte)(167)))), ((int)(((byte)(129)))));
            this.gradientpanel1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(148)))), ((int)(((byte)(164)))), ((int)(((byte)(128)))));
            this.gradientpanel1.Controls.Add(this.label5);
            this.gradientpanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.gradientpanel1.Location = new System.Drawing.Point(0, 0);
            this.gradientpanel1.Name = "gradientpanel1";
            this.gradientpanel1.Size = new System.Drawing.Size(551, 59);
            this.gradientpanel1.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(144, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(230, 38);
            this.label5.TabIndex = 47;
            this.label5.Text = "Оплата послуг";
            // 
            // Reg2
            // 
            this.Reg2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(220)))), ((int)(((byte)(178)))));
            this.Reg2.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Reg2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Reg2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)), true);
            this.Reg2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Reg2.Location = new System.Drawing.Point(130, 328);
            this.Reg2.Name = "Reg2";
            this.Reg2.Size = new System.Drawing.Size(285, 46);
            this.Reg2.TabIndex = 52;
            this.Reg2.Text = "Сплатити";
            this.Reg2.UseVisualStyleBackColor = false;
            this.Reg2.Click += new System.EventHandler(this.Reg2_Click_1);
            // 
            // Coment
            // 
            this.Coment.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Coment.BackColor = System.Drawing.SystemColors.Menu;
            this.Coment.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.Coment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.Coment.Location = new System.Drawing.Point(67, 239);
            this.Coment.Margin = new System.Windows.Forms.Padding(2);
            this.Coment.Multiline = true;
            this.Coment.Name = "Coment";
            this.Coment.Size = new System.Drawing.Size(336, 40);
            this.Coment.TabIndex = 51;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(72, 220);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(174, 17);
            this.label2.TabIndex = 50;
            this.label2.Text = "Призначення / Коментар";
            // 
            // AcadStatu
            // 
            this.AcadStatu.BackColor = System.Drawing.SystemColors.Control;
            this.AcadStatu.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AcadStatu.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.AcadStatu.FormattingEnabled = true;
            this.AcadStatu.Items.AddRange(new object[] {
            "ГРИВНЯ",
            "UAH",
            "ГРИВНЯ",
            "ГРИВНЯ",
            "UAH"});
            this.AcadStatu.Location = new System.Drawing.Point(408, 153);
            this.AcadStatu.Name = "AcadStatu";
            this.AcadStatu.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.AcadStatu.Size = new System.Drawing.Size(113, 30);
            this.AcadStatu.TabIndex = 49;
            this.AcadStatu.Text = "UAH";
            // 
            // Sum
            // 
            this.Sum.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.Sum.BackColor = System.Drawing.SystemColors.Menu;
            this.Sum.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.Sum.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.Sum.Location = new System.Drawing.Point(67, 149);
            this.Sum.Margin = new System.Windows.Forms.Padding(2);
            this.Sum.Multiline = true;
            this.Sum.Name = "Sum";
            this.Sum.Size = new System.Drawing.Size(336, 40);
            this.Sum.TabIndex = 48;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(72, 130);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 47;
            this.label1.Text = "Сума";
            // 
            // Pay
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(188)))), ((int)(((byte)(145)))));
            this.ClientSize = new System.Drawing.Size(551, 505);
            this.Controls.Add(this.Reg2);
            this.Controls.Add(this.Coment);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.AcadStatu);
            this.Controls.Add(this.Sum);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.gradientpanel1);
            this.Name = "Pay";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pay";
            this.Load += new System.EventHandler(this.Pay_Load);
            this.gradientpanel1.ResumeLayout(false);
            this.gradientpanel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private gradientpanel gradientpanel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Reg2;
        private System.Windows.Forms.TextBox Coment;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox AcadStatu;
        private System.Windows.Forms.TextBox Sum;
        private System.Windows.Forms.Label label1;
    }
}
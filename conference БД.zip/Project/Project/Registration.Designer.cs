﻿namespace Project
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.AcadStatus = new System.Windows.Forms.ComboBox();
            this.ScienceDir = new System.Windows.Forms.ComboBox();
            this.passwordLog = new System.Windows.Forms.TextBox();
            this.userlog = new System.Windows.Forms.TextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.PIB = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(48)))), ((int)(((byte)(67)))));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(57)))), ((int)(((byte)(62)))), ((int)(((byte)(81)))));
            this.panel4.Location = new System.Drawing.Point(2, 57);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(320, 119);
            this.panel4.TabIndex = 16;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(164)))), ((int)(((byte)(208)))));
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1044, 741);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(252)))), ((int)(((byte)(255)))));
            this.panel2.Controls.Add(this.AcadStatus);
            this.panel2.Controls.Add(this.ScienceDir);
            this.panel2.Controls.Add(this.passwordLog);
            this.panel2.Controls.Add(this.userlog);
            this.panel2.Controls.Add(this.linkLabel1);
            this.panel2.Controls.Add(this.PIB);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Controls.Add(this.button2);
            this.panel2.Location = new System.Drawing.Point(72, 70);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(900, 600);
            this.panel2.TabIndex = 18;
            // 
            // AcadStatus
            // 
            this.AcadStatus.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.AcadStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.AcadStatus.FormattingEnabled = true;
            this.AcadStatus.Items.AddRange(new object[] {
            "Доцент",
            "Професор",
            "Старший науковий співробітник"});
            this.AcadStatus.Location = new System.Drawing.Point(20, 227);
            this.AcadStatus.Name = "AcadStatus";
            this.AcadStatus.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.AcadStatus.Size = new System.Drawing.Size(328, 38);
            this.AcadStatus.TabIndex = 21;
            this.AcadStatus.SelectedIndexChanged += new System.EventHandler(this.ScienceDir_SelectedIndexChanged);
            // 
            // ScienceDir
            // 
            this.ScienceDir.Font = new System.Drawing.Font("Century Gothic", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.ScienceDir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.ScienceDir.FormattingEnabled = true;
            this.ScienceDir.Items.AddRange(new object[] {
            "Фізико-математичний",
            "Хімічний",
            "Біологіний",
            "Технічний",
            "Економічний",
            "Географічний",
            "Філософський",
            "Юридичний",
            "Педагогічний",
            "Інший"});
            this.ScienceDir.Location = new System.Drawing.Point(20, 271);
            this.ScienceDir.Name = "ScienceDir";
            this.ScienceDir.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ScienceDir.Size = new System.Drawing.Size(328, 38);
            this.ScienceDir.TabIndex = 20;
            this.ScienceDir.SelectedIndexChanged += new System.EventHandler(this.AcadStatus_SelectedIndexChanged);
            // 
            // passwordLog
            // 
            this.passwordLog.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.passwordLog.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passwordLog.ForeColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.passwordLog.Location = new System.Drawing.Point(20, 358);
            this.passwordLog.Margin = new System.Windows.Forms.Padding(2);
            this.passwordLog.Multiline = true;
            this.passwordLog.Name = "passwordLog";
            this.passwordLog.PasswordChar = '*';
            this.passwordLog.Size = new System.Drawing.Size(328, 40);
            this.passwordLog.TabIndex = 19;
            // 
            // userlog
            // 
            this.userlog.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.userlog.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.userlog.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.userlog.ForeColor = System.Drawing.Color.Gray;
            this.userlog.Location = new System.Drawing.Point(20, 314);
            this.userlog.Margin = new System.Windows.Forms.Padding(2);
            this.userlog.Multiline = true;
            this.userlog.Name = "userlog";
            this.userlog.Size = new System.Drawing.Size(328, 40);
            this.userlog.TabIndex = 18;
            this.userlog.TextChanged += new System.EventHandler(this.userlog_TextChanged);
            // 
            // linkLabel1
            // 
            this.linkLabel1.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(214)))), ((int)(((byte)(248)))));
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.BackColor = System.Drawing.Color.Transparent;
            this.linkLabel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.linkLabel1.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(175)))), ((int)(((byte)(164)))), ((int)(((byte)(208)))));
            this.linkLabel1.Font = new System.Drawing.Font("Sitka Text", 9F);
            this.linkLabel1.ForeColor = System.Drawing.Color.Transparent;
            this.linkLabel1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.linkLabel1.LinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(135)))), ((int)(((byte)(248)))));
            this.linkLabel1.Location = new System.Drawing.Point(2, 499);
            this.linkLabel1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(141, 18);
            this.linkLabel1.TabIndex = 17;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Існує обліковий запис";
            this.linkLabel1.VisitedLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(18)))), ((int)(((byte)(117)))));
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // PIB
            // 
            this.PIB.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.PIB.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.PIB.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.PIB.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.PIB.Location = new System.Drawing.Point(20, 182);
            this.PIB.Margin = new System.Windows.Forms.Padding(2);
            this.PIB.Multiline = true;
            this.PIB.Name = "PIB";
            this.PIB.Size = new System.Drawing.Size(328, 40);
            this.PIB.TabIndex = 8;
            this.PIB.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label2.AutoSize = true;
            this.label2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label2.Font = new System.Drawing.Font("Sitka Text", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(187)))), ((int)(((byte)(241)))));
            this.label2.Location = new System.Drawing.Point(12, 120);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(342, 47);
            this.label2.TabIndex = 0;
            this.label2.Text = "Реєстрація аккаунту";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(187)))), ((int)(((byte)(240)))));
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Right;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(358, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(542, 600);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 1;
            this.pictureBox2.TabStop = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(187)))), ((int)(((byte)(241)))));
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(200)))), ((int)(((byte)(187)))), ((int)(((byte)(241)))));
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(205)))), ((int)(((byte)(243)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Sitka Text", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.Gray;
            this.button2.Location = new System.Drawing.Point(137, 424);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(227, 46);
            this.button2.TabIndex = 2;
            this.button2.Text = "ЗАРЕЄСТРУВАТИСЯ";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1044, 741);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Registration";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Registration";
            this.Load += new System.EventHandler(this.Registration_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox PIB;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox userlog;
        private System.Windows.Forms.TextBox passwordLog;
        private System.Windows.Forms.ComboBox ScienceDir;
        private System.Windows.Forms.ComboBox AcadStatus;
    }
}
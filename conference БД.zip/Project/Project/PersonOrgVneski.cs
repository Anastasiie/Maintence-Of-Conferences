﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace Project
{
    public partial class PersonOrgVneski : Form
    {
        DB_Connection DB_Connection = new DB_Connection();

        public PersonOrgVneski()
        {
            InitializeComponent();
        }
        private void CreateColumns()
        {
            //ConferRec.Columns.Add("ConfRegNumb", "Реєстраційний номер конференції");
            Money.Columns.Add("ConfName", "Назва конференції");
            Money.Columns.Add("StartDate", "Дата конференції");
            Money.Columns.Add("PaymentAmount", "Оргвнесок");
            Money.Columns.Add("DatePay", "Дата оплати");
            // ConferRec.Columns.Add("EndDate", "Дата закінчення");
        }
        private void ReadRow(IDataRecord record)
        {
            Money.Rows.Add(record.GetString(0), record.GetDateTime(1), record.GetDecimal(2), record.GetDateTime(3));
            //Money.Rows.Add(record.GetString(1), record.GetDateTime(4), record.GetInt32(8), record.GetDateTime(10));
        }
        private void PersonOrgVneski_Load(object sender, EventArgs e)
        {
            Reader();
        }
        private void Reader()
        {
            CreateColumns();

            var loGin = AllVariable.Login;
            var pasSword = AllVariable.Password;

            var stringQuery = $"SELECT ConfName,StartDate,PaymentAmount,DatePay FROM Conference c JOIN AdmissionFee a ON a.ConfRegNumb=c.ConfRegNumb JOIN Member m ON m.RegistrNumbPerson=a.RegistrNumbPerson  WHERE users_login = '{loGin}' AND users_password = '{pasSword}'";
            SqlCommand command = new SqlCommand(stringQuery, DB_Connection.getConnection());
            DB_Connection.openConnection();

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadRow(reader);
            }
            reader.Close();
            DB_Connection.closeConnection();
        }
        private void Money_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainPage mainPage = new MainPage();
            mainPage.Show();
        }

        private void Person_Data_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            YourConferRecord record = new YourConferRecord();
            record.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
//CadetBlue
namespace Project
{
    public partial class AdInMin : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        int selectedRow;
        public AdInMin()
        {
            InitializeComponent();
        }
        private void CreateColumns()
        {
            Amen.Columns.Add("RegistrNumbPerson", "Номер");
            Amen.Columns.Add("FullName", "ПІБ");
            Amen.Columns.Add("AcadStatus", "Вчене звання");
            Amen.Columns.Add("ScienceDir", "Науковий напрям");
            Amen.Columns.Add("users_login", "Логін");
            Amen.Columns.Add("users_password", "Пароль");
            Amen.Columns.Add("roleType", "Роль");
            //var checkCol = new CheckBox();
        }
        private void ReadRow(IDataRecord record)
        {
            Amen.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetString(4), record.GetString(5), record.GetInt32(6));
        }
        private void RefreshDataGrid() //Read
        {
            Amen.Rows.Clear();
            string querystring = $"SELECT * FROM Member";//ConfName, Country, City, StartDate, EndDate
            SqlCommand command = new SqlCommand(querystring, DB_Connection.getConnection());
            DB_Connection.openConnection();

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                ReadRow(reader);
            }
            reader.Close();
            DB_Connection.closeConnection();

        }
        private void AdminFunction_Load(object sender, EventArgs e)
        {
            CreateColumns();
            RefreshDataGrid();
            this.Amen.Columns["RegistrNumbPerson"].Visible = false;
            //this.Amen.Columns["AcadStatus"].Visible = false;
            //this.Amen.Columns["ScienceDir"].Visible = false;
            PIB.AddPlaceholder("ПІБ");
            ScienceDir.AddComboBoxPlaceholder("Науковий напрям");
            AcadStatus.AddComboBoxPlaceholder("Вчене звання");
            Login.AddPlaceholder("Ім'я або адреса ел.пошти");
            Password.AddPlaceholder("Пароль");
            Role.AddPlaceholder("1 or 2 or 3");
        }

        private void Change_Click(object sender, EventArgs e)
        {
            DB_Connection.openConnection();
            for (int i = 0; i < Amen.Rows.Count; i++)
            { 
                var numb = Amen.Rows[i].Cells[0].Value.ToString();
                var PIB = Amen.Rows[i].Cells[1].Value.ToString();
                var AcadStatus = Amen.Rows[i].Cells[2].Value.ToString();
                var ScienceDir = Amen.Rows[i].Cells[3].Value.ToString();
                var users_login = Amen.Rows[i].Cells[4].Value.ToString();
                var users_password = Amen.Rows[i].Cells[5].Value.ToString();
                var role = Amen.Rows[i].Cells[6].Value.ToString();

                var changeQuery = $"update Member set FullName = '{PIB}', AcademicStatuse  = '{AcadStatus}', ScientificDirection  = '{ScienceDir}', users_login  = '{users_login}', users_password  = '{users_password}' , userRole  = '{role}' where RegistrNumbPerson = '{numb}'";
                var command = new SqlCommand(changeQuery, DB_Connection.getConnection());
                command.ExecuteNonQuery();
            }
            //var selectedRowIndex = dataGridView1.CurrentCell.RowIndex;

            //var numbConf = numb.Text;
            //var nameConf = textBox2.Text;
            //var countryConf = textBox3.Text;
            //var cityConf = textBox4.Text;
            //var dateStart = textBox5.Text; //strt
            //var dateEnD = textBox5.Text;

            //if (dataGridView1.Rows[selectedRowIndex].Cells[0].Value.ToString() != string.Empty)
            //{

            //    dataGridView1.Rows[selectedRowIndex].SetValues(numbConf, nameConf, countryConf, cityConf, dateStart, dateEnD);
            //    dataGridView1.Rows[selectedRowIndex].Cells[6].Value = RowState.Modified;
            //}
            DB_Connection.closeConnection();
            RefreshDataGrid();
        }
        private void DeleteRow()//Удаление
        {
            int index = Amen.CurrentCell.RowIndex; //поточна строка
            Amen.Rows[index].Visible = false;

            if (Amen.Rows[index].Cells[0].Value.ToString() == string.Empty)
            {
                Amen.Rows[index].Cells[6].Value = RowState.Deleted;
                return;
            }
            Amen.Rows[index].Cells[6].Value = RowState.Deleted;
        }
        private void Delete_Click(object sender, EventArgs e)
        {
            DeleteRow();
        }

        private void Add_Click(object sender, EventArgs e)
        {
            var pib = PIB .Text;
            var scientifDirection = AcadStatus.Text;       //Вчене звання
            var scienKnowledge = ScienceDir.Text;          //Науковий напрям
            var login = Login.Text;
            var password = Password.Text;
            var role = Role.Text;
            
            string querystring = $"insert into Member(FullName, AcademicStatuse,ScientificDirection, users_login, users_password, userRole) values('{pib}', '{scientifDirection}', '{scienKnowledge}', '{login}','{password}', '{role}')";

            SqlCommand sqlCommand = new SqlCommand(querystring, DB_Connection.getConnection());
            DB_Connection.openConnection();

            if (sqlCommand.ExecuteNonQuery() == 1)
            {
                MessageBox.Show("Успішно", "Виконано");
            }
            else
            {
                MessageBox.Show("Помилка!");
            }
            DB_Connection.closeConnection();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void gradientpanel1_Paint(object sender, PaintEventArgs e)
        {
            
        }

        private void Role_MouseHover(object sender, EventArgs e)
        {
            gradientpanel1.Visible = true;
        }

        private void Role_MouseLeave(object sender, EventArgs e)
        {
            gradientpanel1.Visible = false;
        }

        private void Amen_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            selectedRow = e.RowIndex;
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row = Amen.Rows[selectedRow];
                //numb.Text = row.Cells[0].Value.ToString();
                PIB.Text = row.Cells[1].Value.ToString();
                Login.Text = row.Cells[2].Value.ToString();
                Password.Text = row.Cells[3].Value.ToString();
                AcadStatus.Text = row.Cells[4].Value.ToString(); //strt
                ScienceDir.Text = row.Cells[5].Value.ToString();
                Role.Text = row.Cells[6].Value.ToString();
            }
            //DB_Connection.openConnection();

            //var Numb = Convert.ToInt32(Amen.Rows[e.RowIndex].Cells[0].Value); //index текущ.строки, знач. 0 стовпця
            //var deleteQuery = $"delete from Conference where ConfRegNumb = {Numb}";

            //var command = new SqlCommand(deleteQuery, DB_Connection.getConnection());
            //command.ExecuteNonQuery();
            //////int rowIndex = Amen.CurrentCell.RowIndex; //текущ
            ////int num = Convert.ToInt32(Amen.Rows[e.RowIndex].Cells[RegistrNumbPerson].FormattedValue.ToString());
            //////int num = Convert.ToInt32(Amen.Rows[rowIndex].Cells[0].Value);
            ////string deletequery = $"DELETE FROM Member WHERE RegistrNumbPerson = {num}";

            ////SqlCommand command = new SqlCommand(deletequery, DB_Connection.getConnection());
            ////command.ExecuteNonQuery();

            //DB_Connection.closeConnection();
            //RefreshDataGrid();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RefreshDataGrid();
        }

        private void AcadStatus_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        private void update()
        {
            DB_Connection.openConnection();

            for (int i = 0; i < Amen.Rows.Count; i++)
            {
                var rowState = (RowState)Amen.Rows[i].Cells[6].Value;
                if (rowState == RowState.Existed)
                {
                    continue;
                }
                if (rowState == RowState.Deleted)
                {
                    var Numb = Convert.ToInt32(Amen.Rows[i].Cells[0].Value); //index текущ.строки, знач. 0 стовпця
                    var daleteQuery = $"delete from Member where RegistrNumbPerson = {Numb}";

                    var command = new SqlCommand(daleteQuery, DB_Connection.getConnection());
                    command.ExecuteNonQuery();
                }
                if (rowState == RowState.Modified)
                {
                    var numb = Amen.Rows[i].Cells[0].Value.ToString();
                    var PIB = Amen.Rows[i].Cells[1].Value.ToString();
                    var AcadStatus = Amen.Rows[i].Cells[2].Value.ToString();
                    var ScienceDir = Amen.Rows[i].Cells[3].Value.ToString();
                    var users_login = Amen.Rows[i].Cells[4].Value.ToString();
                    var users_password = Amen.Rows[i].Cells[5].Value.ToString();
                    var role = Amen.Rows[i].Cells[6].Value.ToString();

                    var changeQuery = $"update Member set FullName = '{PIB}', AcademicStatuse  = '{AcadStatus}', ScientificDirection  = '{ScienceDir}', users_login  = '{users_login}', users_password  = '{users_password}' , userRole  = '{role}' where RegistrNumbPerson = '{numb}'";
                    var command = new SqlCommand(changeQuery, DB_Connection.getConnection());
                    command.ExecuteNonQuery();
                }
            }
            DB_Connection.closeConnection();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            update();
        }

        private void Amen_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}

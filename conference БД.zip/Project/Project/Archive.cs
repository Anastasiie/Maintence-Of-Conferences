﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class Archive : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public Archive()
        {
            InitializeComponent();
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
        private void ReadRow(DataGridView dataGridView, IDataRecord record)
        {
            dataGridView.Rows.Add(record.GetInt32(0), record.GetString(1), record.GetString(2), record.GetString(3), record.GetDateTime(4), record.GetDateTime(5));
        }
        private void CreateColumns()
        {
            dataGridView1.Columns.Add("ConfRegNumb", "Реєстраційний номер конференції");
            dataGridView1.Columns.Add("ConfName", "Назва конференції");
            dataGridView1.Columns.Add("Country", "Країна");
            dataGridView1.Columns.Add("City", "Місто");
            dataGridView1.Columns.Add("StartDate", "Дата початку");
            dataGridView1.Columns.Add("EndDate", "Дата закінчення");
        }
        private void Archive_Load(object sender, EventArgs e)
        {
            CreateColumns();
            var stringQuery = $"SELECT * FROM Conference WHERE StartDate <=  current_timestamp";
            SqlCommand command = new SqlCommand(stringQuery, DB_Connection.getConnection());
            DB_Connection.openConnection();

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadRow(dataGridView1, reader);
            }
            reader.Close();
            DB_Connection.closeConnection();
            this.dataGridView1.Columns["ConfRegNumb"].Visible = false;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void MenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void MenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            label3.Text = "Have a nice day";
            
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            if (label3.Text == "Have a nice day") 
            {
                label3.Text = ":)";
                timer1.Start();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Contacts contacts = new Contacts();
            contacts.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Person_Data_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainPage mainPage = new MainPage();
            mainPage.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            Materials materials = new Materials();
            materials.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (this.Opacity > 0.0)
            {
                this.Opacity -= 0.025;
            }
            else
            {
                timer1.Stop();
                Application.Exit();
            }
        }

        private void Archive_Leave(object sender, EventArgs e)
        {
            
        }
    }
}

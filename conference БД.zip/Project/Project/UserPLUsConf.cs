﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class UserPLUsConf : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public UserPLUsConf()
        {
            InitializeComponent();
        }

        private void UserPLUsConf_Load(object sender, EventArgs e)
        {
            dateConf.AddPlaceholder("рр/мм/дд 00:00:00.000");
            CreateColumns();
        }
        private void ReadRow(DataGridView dataGridView, IDataRecord record)
        {
            dataGridView.Rows.Add(record.GetString(0), record.GetDateTime(1), record.GetDateTime(2));
        }

        private void Task1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
        private void CreateColumns()
        {
            Task1.Columns.Add("FullName", "ПІБ"); //FullName, DateReg, StartDate
            Task1.Columns.Add("DateReg", "Дата реєстрації");
            Task1.Columns.Add("StartDate", "Початок конференції");
        }
        private void dateConf_Enter(object sender, EventArgs e)
        {
            
        }

        private void New_Click(object sender, EventArgs e)
        {
            var date = dateConf.Text;
            int count = 0;
            var stringQuery = $"SELECT FullName, DateReg, StartDate FROM Member m JOIN Registration r ON m.RegistrNumbPerson = r.RegistrNumbPerson JOIN Conference c ON r.ConfRegNumb = c.ConfRegNumb WHERE c.StartDate = '{date}' ";//'2022/12/07 9:00:00.000'
            SqlCommand command = new SqlCommand(stringQuery, DB_Connection.getConnection());
            DB_Connection.openConnection();

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadRow(Task1, reader);
                count++;
            }
            CountPers.Text = Convert.ToString(count);
            reader.Close();
            DB_Connection.closeConnection();
        }

        private void dateConf_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

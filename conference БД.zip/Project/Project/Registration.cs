﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class Registration : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public Registration()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Registration_Load(object sender, EventArgs e)
        {
            Size = new Size(1060, 780);//
            FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Регістрація";
            
            PIB.AddPlaceholder("ПІБ");
            ScienceDir.AddComboBoxPlaceholder("Науковий напрям");
            AcadStatus.AddComboBoxPlaceholder("Вчене звання");
            userlog.AddPlaceholder("Ім'я або адреса ел.пошти");
            passwordLog.AddPlaceholder("Пароль");
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            LogIn LogIn = new LogIn();
            LogIn.Show();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Leave(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel2_Leave(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DB_Connection dB_Connection = new DB_Connection();

            var FullName = PIB.Text;
            var ScienKnowledge = ScienceDir.Text;    //Науковий напрям
            var ScientifDirection = AcadStatus.Text;       //Вчене звання
            var login = userlog.Text;
            var password=passwordLog.Text;

            string querystring = $"insert into Member(FullName, AcademicStatuse,ScientificDirection, users_login, users_password, userRole) values('{FullName}', '{ScientifDirection}', '{ScienKnowledge}', '{login}','{password}', 3)";

            SqlCommand sqlCommand = new SqlCommand(querystring, DB_Connection.getConnection());
            DB_Connection.openConnection();

            if (ScienceDir.Text == "Науковий напрям" ^ ScienceDir.Text == "")
            {
                MessageBox.Show("Оберіть науковий напрям");
            }
            else if (AcadStatus.Text == "Вчене звання" ^ AcadStatus.Text == "")
            {
                MessageBox.Show("Оберіть вчене звання");
            }

            if(sqlCommand.ExecuteNonQuery()==1)
            {
                MessageBox.Show("Акаунт успішно створено", "Успішно");
                this.Hide();
                LogIn LogIn = new LogIn();
                LogIn.Show();
            }
            else
            {
                MessageBox.Show("Помилка! Акаунт не створено");
            }
            
            dB_Connection.closeConnection();

            
            
        }

        private Boolean checkUser()
        {
            var Fullname = PIB.Text;
            var ScienKnow = ScienceDir.Text;    //Науковий напрям
            var ScienDir = AcadStatus.Text;
            var loginUser = userlog.Text;
            var passUser = passwordLog.Text;

            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter();
            DataTable dt = new DataTable();
            string querystring = $"select * from Member where FullName = '{Fullname}', AcademicStatuse = '{ScienDir}',ScientificDirection = '{ScienKnow}', users_login = '{loginUser}', users_password = '{passUser}'";

            SqlCommand command = new SqlCommand(querystring, DB_Connection.getConnection());

            sqlDataAdapter.SelectCommand = command;
            sqlDataAdapter.Fill(dt);

            if(dt.Rows.Count > 0)
            {
                MessageBox.Show("Користувач вже існує");
                return true;
            }
            else return false;
        }

        private void userlog_TextChanged(object sender, EventArgs e)
        {

        }

        private void AcadStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void ScienceDir_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}

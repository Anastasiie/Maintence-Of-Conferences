﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;
using System.Security.Policy;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Window;

namespace Project
{
    public partial class PersonalPage : Form
    {
        DB_Connection DB_Connection = new DB_Connection();

        public PersonalPage()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void close_eye_Click(object sender, EventArgs e)
        {
            pass.UseSystemPasswordChar = true;
            open_eye.Visible = true;
            close_eye.Visible=false;
            pass.ReadOnly=false;
        }

        private void open_eye_Click(object sender, EventArgs e)
        {
            //pass.ReadOnly = true;
            pass.UseSystemPasswordChar = false;
            open_eye.Visible = false;
            close_eye.Visible = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainPage mainPage = new MainPage();
            mainPage.Show();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            YourConferRecord your = new YourConferRecord();
            your.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonOrgVneski personOrgVneski = new PersonOrgVneski();
            personOrgVneski.Show();
        }
        private void PIBInf()
        {
            var loGin = AllVariable.Login;
            var pasSword = AllVariable.Password;
            userlog.Text = loGin.ToString();
            pass.Text = pasSword.ToString();

            DB_Connection.openConnection();
            for (int i = 0; i < 4; i++)
            {
                switch (i)
                {
                    case 0:
                        DB_Connection.openConnection();
                        var stringQuery = $"SELECT FullName FROM Member WHERE users_login = '{loGin}' AND users_password ='{pasSword}'";
                        SqlCommand c = new SqlCommand(stringQuery, DB_Connection.getConnection());
                        SqlDataReader dr = c.ExecuteReader();

                        string Name = "";

                        while (dr.Read())
                        {
                            Name = dr[0].ToString();
                        }
                        textBoxFullname.Text = Name;
                        DB_Connection.closeConnection();
                        break;
                    case 1:
                        DB_Connection.openConnection();
                        var stringquery = $"SELECT AcademicStatuse FROM Member WHERE users_login = '{loGin}' AND users_password ='{pasSword}'";
                        SqlCommand com = new SqlCommand(stringquery, DB_Connection.getConnection());
                        SqlDataReader datr = com.ExecuteReader();

                        string AcademicStatuse = "";

                        while (datr.Read())
                        {
                            AcademicStatuse = datr[0].ToString();
                        }
                        textBoxAcad.Text = AcademicStatuse;
                        DB_Connection.closeConnection();
                        break;
                    case 2:
                        DB_Connection.openConnection();
                        var stringuery = $"SELECT ScientificDirection FROM Member WHERE users_login = '{loGin}' AND users_password ='{pasSword}'";
                        SqlCommand command = new SqlCommand(stringuery, DB_Connection.getConnection());
                        SqlDataReader dreader = command.ExecuteReader();

                        string ScientificDirection = "";

                        while (dreader.Read())
                        {
                            ScientificDirection = dreader[0].ToString();
                        }
                        textBoxDir.Text = ScientificDirection;
                        DB_Connection.closeConnection();
                        break;
                    case 3:
                        DB_Connection.openConnection();
                        var String = $"SELECT roleType FROM Member m INNER JOIN Role r ON m.userRole=r.roleId WHERE users_login = '{loGin}' AND users_password ='{pasSword}'";
                        SqlCommand comm = new SqlCommand(String, DB_Connection.getConnection());
                        SqlDataReader dataReader = comm.ExecuteReader();

                        string Role = "";

                        while (dataReader.Read())
                        {
                            Role = dataReader[0].ToString();
                        }
                        textBoxrole.Text = Role;
                        DB_Connection.closeConnection();
                        break;
                    default: 
                        break;
                }
            }
            
        }
        private void PersonalPage_Load(object sender, EventArgs e)
        {
            PIBInf();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void close_eye_Click_1(object sender, EventArgs e)
        {
            pass.Enabled = true;
            pass.UseSystemPasswordChar = true;
            open_eye.Visible = true;
            close_eye.Visible = false;
            //pass.ReadOnly = false;
        }

        private void open_eye_Click_1(object sender, EventArgs e)
        {
            pass.Enabled = false;
            pass.UseSystemPasswordChar = false;
            open_eye.Visible = false;
            close_eye.Visible = true;
            
        }

        private void New_Click(object sender, EventArgs e)
        {
            var loGin = AllVariable.Login;
            var pasSword = AllVariable.Password;

            var paswrd = pass.Text;

            if (paswrd.ToString() != string.Empty)
            {
                DialogResult result = MessageBox.Show("Ви впевнені?","Підтвердження операції",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    DB_Connection.openConnection();
                    var changeQuery = $"update Member set users_password = '{paswrd}' WHERE users_login = '{loGin}' AND users_password ='{pasSword}'";
                    var command = new SqlCommand(changeQuery, DB_Connection.getConnection());
                    command.ExecuteNonQuery();
                    DB_Connection.closeConnection();
                    MessageBox.Show("Пароль змінено", "Виконано", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else MessageBox.Show("Відмова операції", "Виконано", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else MessageBox.Show("Пусте поле", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }
}

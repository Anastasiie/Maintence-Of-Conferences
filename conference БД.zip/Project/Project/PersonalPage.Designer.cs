﻿namespace Project
{
    partial class PersonalPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PersonalPage));
            this.gradientpanel1 = new Project.gradientpanel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.Person_Data = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.close_eye = new System.Windows.Forms.Button();
            this.pass = new System.Windows.Forms.TextBox();
            this.userlog = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.open_eye = new System.Windows.Forms.Button();
            this.textBoxrole = new System.Windows.Forms.TextBox();
            this.textBoxFullname = new System.Windows.Forms.TextBox();
            this.textBoxAcad = new System.Windows.Forms.TextBox();
            this.textBoxDir = new System.Windows.Forms.TextBox();
            this.UPD = new System.Windows.Forms.Button();
            this.gradientpanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // gradientpanel1
            // 
            this.gradientpanel1.ColorBottom = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(180)))), ((int)(((byte)(222)))));
            this.gradientpanel1.ColorTop = System.Drawing.Color.FromArgb(((int)(((byte)(176)))), ((int)(((byte)(195)))), ((int)(((byte)(224)))));
            this.gradientpanel1.Controls.Add(this.button4);
            this.gradientpanel1.Controls.Add(this.button3);
            this.gradientpanel1.Controls.Add(this.Person_Data);
            this.gradientpanel1.Controls.Add(this.button1);
            this.gradientpanel1.Controls.Add(this.pictureBox1);
            this.gradientpanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.gradientpanel1.Location = new System.Drawing.Point(0, 0);
            this.gradientpanel1.Name = "gradientpanel1";
            this.gradientpanel1.Size = new System.Drawing.Size(278, 661);
            this.gradientpanel1.TabIndex = 1;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(213)))), ((int)(((byte)(227)))));
            this.button4.Dock = System.Windows.Forms.DockStyle.Top;
            this.button4.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.Location = new System.Drawing.Point(0, 368);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(278, 49);
            this.button4.TabIndex = 9;
            this.button4.Text = "Записані конференції";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(213)))), ((int)(((byte)(227)))));
            this.button3.Dock = System.Windows.Forms.DockStyle.Top;
            this.button3.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(0, 319);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(278, 49);
            this.button3.TabIndex = 8;
            this.button3.Text = "Витрати";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Person_Data
            // 
            this.Person_Data.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(180)))), ((int)(((byte)(222)))));
            this.Person_Data.Dock = System.Windows.Forms.DockStyle.Top;
            this.Person_Data.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.Person_Data.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Person_Data.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Person_Data.Location = new System.Drawing.Point(0, 270);
            this.Person_Data.Name = "Person_Data";
            this.Person_Data.Size = new System.Drawing.Size(278, 49);
            this.Person_Data.TabIndex = 7;
            this.Person_Data.Text = "Персональні дані";
            this.Person_Data.UseVisualStyleBackColor = false;
            this.Person_Data.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(213)))), ((int)(((byte)(227)))));
            this.button1.Dock = System.Windows.Forms.DockStyle.Top;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(0, 221);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(278, 49);
            this.button1.TabIndex = 6;
            this.button1.Text = "Головна сторінка";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(278, 221);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(321, 71);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(275, 38);
            this.label6.TabIndex = 34;
            this.label6.Text = "Персональні дані";
            // 
            // close_eye
            // 
            this.close_eye.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.close_eye.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.close_eye.Image = ((System.Drawing.Image)(resources.GetObject("close_eye.Image")));
            this.close_eye.Location = new System.Drawing.Point(708, 480);
            this.close_eye.Name = "close_eye";
            this.close_eye.Size = new System.Drawing.Size(32, 32);
            this.close_eye.TabIndex = 32;
            this.close_eye.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.close_eye.UseVisualStyleBackColor = true;
            this.close_eye.Click += new System.EventHandler(this.close_eye_Click_1);
            // 
            // pass
            // 
            this.pass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.pass.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.pass.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pass.Enabled = false;
            this.pass.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.pass.ForeColor = System.Drawing.Color.Gray;
            this.pass.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.pass.Location = new System.Drawing.Point(436, 476);
            this.pass.Margin = new System.Windows.Forms.Padding(2);
            this.pass.Multiline = true;
            this.pass.Name = "pass";
            this.pass.PasswordChar = '*';
            this.pass.Size = new System.Drawing.Size(267, 40);
            this.pass.TabIndex = 31;
            // 
            // userlog
            // 
            this.userlog.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.userlog.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.userlog.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.userlog.Enabled = false;
            this.userlog.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.userlog.ForeColor = System.Drawing.Color.Gray;
            this.userlog.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.userlog.Location = new System.Drawing.Point(436, 416);
            this.userlog.Margin = new System.Windows.Forms.Padding(2);
            this.userlog.Multiline = true;
            this.userlog.Name = "userlog";
            this.userlog.ReadOnly = true;
            this.userlog.Size = new System.Drawing.Size(267, 40);
            this.userlog.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(331, 484);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 24);
            this.label5.TabIndex = 29;
            this.label5.Text = "Пароль";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(356, 424);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 24);
            this.label4.TabIndex = 28;
            this.label4.Text = "Логін";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(370, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(147, 24);
            this.label3.TabIndex = 26;
            this.label3.Text = "Вчене звання";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(320, 268);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(197, 24);
            this.label2.TabIndex = 24;
            this.label2.Text = "Науковий напрям";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(476, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 24);
            this.label1.TabIndex = 22;
            this.label1.Text = "ПІБ";
            // 
            // open_eye
            // 
            this.open_eye.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.open_eye.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.open_eye.Image = ((System.Drawing.Image)(resources.GetObject("open_eye.Image")));
            this.open_eye.Location = new System.Drawing.Point(708, 480);
            this.open_eye.Name = "open_eye";
            this.open_eye.Size = new System.Drawing.Size(32, 32);
            this.open_eye.TabIndex = 33;
            this.open_eye.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.open_eye.UseVisualStyleBackColor = true;
            this.open_eye.Visible = false;
            this.open_eye.Click += new System.EventHandler(this.open_eye_Click_1);
            // 
            // textBoxrole
            // 
            this.textBoxrole.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(180)))), ((int)(((byte)(222)))));
            this.textBoxrole.Enabled = false;
            this.textBoxrole.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxrole.ForeColor = System.Drawing.Color.Black;
            this.textBoxrole.Location = new System.Drawing.Point(1076, 12);
            this.textBoxrole.Name = "textBoxrole";
            this.textBoxrole.ReadOnly = true;
            this.textBoxrole.Size = new System.Drawing.Size(109, 26);
            this.textBoxrole.TabIndex = 56;
            this.textBoxrole.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBoxrole.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // textBoxFullname
            // 
            this.textBoxFullname.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBoxFullname.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxFullname.Enabled = false;
            this.textBoxFullname.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.textBoxFullname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.textBoxFullname.Location = new System.Drawing.Point(522, 152);
            this.textBoxFullname.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxFullname.Multiline = true;
            this.textBoxFullname.Name = "textBoxFullname";
            this.textBoxFullname.Size = new System.Drawing.Size(663, 40);
            this.textBoxFullname.TabIndex = 95;
            // 
            // textBoxAcad
            // 
            this.textBoxAcad.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBoxAcad.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxAcad.Enabled = false;
            this.textBoxAcad.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.textBoxAcad.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.textBoxAcad.Location = new System.Drawing.Point(522, 209);
            this.textBoxAcad.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxAcad.Multiline = true;
            this.textBoxAcad.Name = "textBoxAcad";
            this.textBoxAcad.Size = new System.Drawing.Size(663, 40);
            this.textBoxAcad.TabIndex = 96;
            // 
            // textBoxDir
            // 
            this.textBoxDir.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.textBoxDir.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.textBoxDir.Enabled = false;
            this.textBoxDir.Font = new System.Drawing.Font("Sitka Text", 14.25F);
            this.textBoxDir.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(120)))), ((int)(((byte)(129)))));
            this.textBoxDir.Location = new System.Drawing.Point(522, 263);
            this.textBoxDir.Margin = new System.Windows.Forms.Padding(2);
            this.textBoxDir.Multiline = true;
            this.textBoxDir.Name = "textBoxDir";
            this.textBoxDir.Size = new System.Drawing.Size(663, 40);
            this.textBoxDir.TabIndex = 97;
            // 
            // UPD
            // 
            this.UPD.BackColor = System.Drawing.Color.Transparent;
            this.UPD.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.UPD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.UPD.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.UPD.Location = new System.Drawing.Point(511, 534);
            this.UPD.Name = "UPD";
            this.UPD.Size = new System.Drawing.Size(113, 30);
            this.UPD.TabIndex = 98;
            this.UPD.Text = "Зберегти";
            this.UPD.UseVisualStyleBackColor = false;
            this.UPD.Click += new System.EventHandler(this.New_Click);
            // 
            // PersonalPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(151)))), ((int)(((byte)(180)))), ((int)(((byte)(222)))));
            this.ClientSize = new System.Drawing.Size(1284, 661);
            this.Controls.Add(this.UPD);
            this.Controls.Add(this.textBoxDir);
            this.Controls.Add(this.textBoxAcad);
            this.Controls.Add(this.textBoxFullname);
            this.Controls.Add(this.textBoxrole);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.close_eye);
            this.Controls.Add(this.pass);
            this.Controls.Add(this.userlog);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.open_eye);
            this.Controls.Add(this.gradientpanel1);
            this.Name = "PersonalPage";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "PersonalPage";
            this.Load += new System.EventHandler(this.PersonalPage_Load);
            this.gradientpanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private gradientpanel gradientpanel1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button Person_Data;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button close_eye;
        private System.Windows.Forms.TextBox pass;
        private System.Windows.Forms.TextBox userlog;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button open_eye;
        private System.Windows.Forms.TextBox textBoxrole;
        private System.Windows.Forms.TextBox textBoxFullname;
        private System.Windows.Forms.TextBox textBoxAcad;
        private System.Windows.Forms.TextBox textBoxDir;
        private System.Windows.Forms.Button UPD;
    }
}
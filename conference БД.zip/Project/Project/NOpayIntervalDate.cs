﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class NOpayIntervalDate : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public NOpayIntervalDate()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Task2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void ReadRow(DataGridView dataGridView, IDataRecord record)
        {
            Task3.Rows.Add(record.GetString(0), record.GetDateTime(1), record.GetDecimal(2));
        }
        private void CreateColumns()
        {
            Task3.Columns.Add("FullName", "ПІБ"); //FullName, DatePay, PaymentAmount
            Task3.Columns.Add("DatePay", "Дата сплати оргвнеску");
            Task3.Columns.Add("PaymentAmount", "Не сплачено");
        }
        private void NOpayIntervalDate_Load(object sender, EventArgs e)
        {
            CreateColumns();
            dateBefore.AddPlaceholder("2022/12/03 00:00:00.000");
            dateAfter.AddPlaceholder("2022/12/07 10:00:00.000");
        }

        private void New_Click(object sender, EventArgs e)
        {
            var date1 = dateBefore.Text;
            var date2 = dateAfter.Text;
            var stringQuery = $"SELECT FullName, DatePay, PaymentAmount FROM Member m LEFT OUTER JOIN AdmissionFee a ON m.RegistrNumbPerson=a.RegistrNumbPerson WHERE a.DatePay BETWEEN '{date1}' AND'{date2}' AND a.PaymentAmount = 0";
            //'2022/12/03 00:00:00.000', '2022/12/07 10:00:00.000' '{dateBefore}'
            SqlCommand command = new SqlCommand(stringQuery, DB_Connection.getConnection());
            DB_Connection.openConnection();

            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                ReadRow(Task3, reader);
            }
            reader.Close();
            DB_Connection.closeConnection();
        }
    }
}

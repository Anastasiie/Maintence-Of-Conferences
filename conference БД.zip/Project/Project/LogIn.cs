﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class LogIn : Form
    {
        DB_Connection DB_Connection = new DB_Connection();
        public LogIn()
        {
            InitializeComponent();

            this.password.AutoSize=false;
            this.password.Size=new Size(this.password.Size.Width,40);
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Size = new Size(1060, 780);// 769,534
            FormBorderStyle = FormBorderStyle.FixedSingle;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Вхід";
            userlog.AddPlaceholder("Ім'я або адреса ел.пошти");
            password.AddPlaceholder("Пароль");
            password.PasswordChar = '*';
                        
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AllVariable.Login =userlog.Text;
            AllVariable.Password =password.Text;
            
            if (userlog.Text == String.Empty)
            {
                MessageBox.Show("Помилка", "Пусте поле логіну!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (password.Text == String.Empty)
            {
                MessageBox.Show("Помилка", "Пусте поле паролю!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else { 
                var loginUser = userlog.Text;
                var passwordUser = password.Text;

                SqlDataAdapter adapter = new SqlDataAdapter();
                DataTable dt = new DataTable();

                string queryString = $"select RegistrNumbPerson, FullName, AcademicStatuse, ScientificDirection, users_login, users_password, userRole from Member where users_login = '{loginUser}' and users_password = '{passwordUser}'";

                SqlCommand sqlCommand = new SqlCommand(queryString, DB_Connection.getConnection());
                adapter.SelectCommand = sqlCommand;
                adapter.Fill(dt);

                if (dt.Rows.Count == 1)
                {
                    var user = new Role(dt.Rows[0].ItemArray[4].ToString(), Convert.ToInt32(dt.Rows[0].ItemArray[6]));

                    MessageBox.Show("Вхід виконано", "Успішно!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    MainPage mainPage = new MainPage();//user
                    this.Hide();
                    mainPage.Show();
                }
                else 
                {
                    MessageBox.Show("Такого акаунту не існує", "Акаунту не існує!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Registration registration = new Registration();
            registration.Show();
        }

        private void passwordLog_Click(object sender, EventArgs e)
        {

        }

        private void LogIn_Leave(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void textBox1_Leave(object sender, EventArgs e)
        {

        }
    }
}

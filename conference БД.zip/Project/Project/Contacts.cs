﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Contacts : Form
    {
        public Contacts()
        {
            InitializeComponent();
        }

        private void gradientpanel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Person_Data_Click(object sender, EventArgs e)
        {
            //this.Hide();
            //MainPage mainPage = new MainPage();
            //mainPage.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Archive archive = new Archive();
            archive.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void Person_Data_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            MainPage mainPage = new MainPage();
            mainPage.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Archive archive = new Archive();
            archive.Show();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Materials materials = new Materials();
            materials.Show();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            PersonalPage personalPage = new PersonalPage();
            personalPage.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button4_Leave(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
